//ZAD 1
const int NUMBER_34 = 34;
//ZAD 4
const int DEFAULT_LEN = 5;
const std::string DEFAULT_S_NAME = "default";
const std::string DEFAULT_STRING = "bezp: ";
const std::string PARAMETER_STRING = "parametr: ";
const std::string COPY_STRING = "kopiuj: ";
const std::string DELETE_STRING = "usuwam: ";

const std::string SIZE_STRING = "Size: ";

const int SIZE_X = 5;
const int SIZE_Y = 4;
const std::string ZAD1 = "ZAD 1";
const std::string ZAD2 = "\nZAD 2";
const std::string ZAD3 = "\nZAD 3";
const std::string ZAD4 = "\nZAD 4";